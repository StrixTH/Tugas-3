# Space-Shooter-Game-in-Java-Using-Greenfoot
This is my first project that I have completed by making a game in Java with Greenfoot. I made this project to finish my Object-Oriented Programming class, which uses the Java language.

To use it, download greenfoot first
https://www.greenfoot.org/download

To run it, open project.greenfoot.
