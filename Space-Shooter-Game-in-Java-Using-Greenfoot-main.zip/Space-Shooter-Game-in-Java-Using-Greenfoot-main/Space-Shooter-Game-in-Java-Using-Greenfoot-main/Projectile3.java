import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Projectile3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Projectile3 extends Skills
{
    public void act()
    {
        moveObj();
        removeProjectileObj();
    }
}
